from .downloader import YouTubeDownloader
from .cli import main

__version__ = "0.1.0"
__all__ = ["YouTubeDownloader", "main"]
